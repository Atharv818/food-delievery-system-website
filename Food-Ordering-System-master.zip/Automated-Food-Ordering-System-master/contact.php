<?php include 'inc/header.php';?>

 <div class="main">
    <div class="content">
    	<div class="support">
  			<div class="support_desc">
  				<h3>Opening Time</h3>
  				<p>8am-10pm| 7 days a week</p>
  				<p> We prepares and serves food and drinks to customers in exchange for money.Customer can select varieties food items and order by either offline or online payment. 
  					 </p>
  			</div>
  				<img src="web/images/contact.png" alt="" />
  			<div class="clear"></div>
  		</div>
    	<div class="section group">
				<div class="col span_2_of_3">
				  <div class="contact-form">
				  	<h2>Contact Us</h2>
					    <form>
					    	<div>
						    	<span><label>NAME</label></span>
						    	<span><input type="text" value=""></span>
						    </div>
						    
						    <div>
						     	<span><label>MOBILE.NO</label></span>
						    	<span><input type="text" value=""></span>
						    </div>
						    <div>
						    	<span><label>SUBJECT</label></span>
						    	<span><input type="text" value=""></span>
						    
						    </div>
						   <div>
						   		<span><input type="submit" value="SUBMIT"></span>
						  </div>
					    </form>
				  </div>
  				</div>
				<div class="col span_1_of_3">
      			<div class="company_address">
				     	<h2>Company Information</h2>
						    	<p>2 no road ,Muradpur</p>
						   		<p>Chittagong</p>
						   		<p>Bnagladesh</p>
				   		<p>Phone:(00) 222 666 444</p>
				   		
				 	 	<p>Email: <span>muktaghoshjoya@abc.com</span></p>
				   		<p>Follow on: <span>Facebook</span>, <span>Twitter</span></p>
				   </div>
				 </div>
			  </div>    	
    </div>
 </div>
</div>
   <?php include 'inc/footer.php';?>