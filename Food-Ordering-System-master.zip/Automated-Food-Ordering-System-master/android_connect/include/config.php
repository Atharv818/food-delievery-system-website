?php

 define("DB_HOST", "localhost");
 define("DB_USER", "android");
 define("DB_PASSWORD", "android");
 define("DB_NAME", "androidlogin");

?>