# Automated-Food-Ordering-System
This is an website for ordering food via online.Here have Customer, Admin ,Cook and Waiter panel to make order full-fill.Customer can make order food in restaurant and home-delivery both. There have intregated PayPal system also for online payment.Also can pay as offline payment.both with   I  use PHP(backend), CSS ,HTML,
